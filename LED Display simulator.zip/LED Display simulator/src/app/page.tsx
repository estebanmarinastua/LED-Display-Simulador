"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  Play,
  Pause,
  RotateCcw,
  Type,
  Sun,
  Gauge,
  Sparkles,
  Monitor,
} from "lucide-react";

// ─── 5×7 Dot-Matrix Font Data ───────────────────────────────────────
// Each character is a 5-column × 7-row bitmap stored as an array of 5 numbers.
// Each number's bits represent rows (bit 0 = top row).
const FONT: Record<string, number[]> = {
  A: [0x7E, 0x11, 0x11, 0x11, 0x7E],
  B: [0x7F, 0x49, 0x49, 0x49, 0x36],
  C: [0x3E, 0x41, 0x41, 0x41, 0x22],
  D: [0x7F, 0x41, 0x41, 0x22, 0x1C],
  E: [0x7F, 0x49, 0x49, 0x49, 0x41],
  F: [0x7F, 0x09, 0x09, 0x09, 0x01],
  G: [0x3E, 0x41, 0x49, 0x49, 0x3A],
  H: [0x7F, 0x08, 0x08, 0x08, 0x7F],
  I: [0x41, 0x41, 0x7F, 0x41, 0x41],
  J: [0x20, 0x40, 0x40, 0x40, 0x3F],
  K: [0x7F, 0x08, 0x14, 0x22, 0x41],
  L: [0x7F, 0x40, 0x40, 0x40, 0x40],
  M: [0x7F, 0x02, 0x0C, 0x02, 0x7F],
  N: [0x7F, 0x04, 0x08, 0x10, 0x7F],
  O: [0x3E, 0x41, 0x41, 0x41, 0x3E],
  P: [0x7F, 0x09, 0x09, 0x09, 0x06],
  Q: [0x3E, 0x41, 0x51, 0x21, 0x5E],
  R: [0x7F, 0x09, 0x19, 0x29, 0x46],
  S: [0x26, 0x49, 0x49, 0x49, 0x32],
  T: [0x01, 0x01, 0x7F, 0x01, 0x01],
  U: [0x3F, 0x40, 0x40, 0x40, 0x3F],
  V: [0x07, 0x18, 0x60, 0x18, 0x07],
  W: [0x3F, 0x40, 0x38, 0x40, 0x3F],
  X: [0x63, 0x14, 0x08, 0x14, 0x63],
  Y: [0x03, 0x04, 0x78, 0x04, 0x03],
  Z: [0x61, 0x51, 0x49, 0x45, 0x43],
  "0": [0x3E, 0x51, 0x49, 0x45, 0x3E],
  "1": [0x00, 0x42, 0x7F, 0x40, 0x00],
  "2": [0x42, 0x61, 0x51, 0x49, 0x46],
  "3": [0x22, 0x41, 0x49, 0x49, 0x36],
  "4": [0x18, 0x14, 0x12, 0x7F, 0x10],
  "5": [0x27, 0x45, 0x45, 0x45, 0x39],
  "6": [0x3E, 0x49, 0x49, 0x49, 0x32],
  "7": [0x01, 0x71, 0x09, 0x05, 0x03],
  "8": [0x36, 0x49, 0x49, 0x49, 0x36],
  "9": [0x26, 0x49, 0x49, 0x49, 0x3E],
  " ": [0x00, 0x00, 0x00, 0x00, 0x00],
  "!": [0x00, 0x00, 0x5F, 0x00, 0x00],
  "?": [0x02, 0x01, 0x51, 0x09, 0x06],
  ".": [0x00, 0x60, 0x60, 0x00, 0x00],
  ",": [0x00, 0x56, 0x36, 0x00, 0x00],
  ":": [0x00, 0x36, 0x36, 0x00, 0x00],
  "-": [0x00, 0x14, 0x14, 0x14, 0x00],
  "_": [0x00, 0x00, 0x00, 0x00, 0x70],
  "'": [0x08, 0x04, 0x00, 0x00, 0x00],
  "\"": [0x14, 0x08, 0x14, 0x00, 0x00],
  "/": [0x02, 0x01, 0x02, 0x04, 0x08],
  "\\": [0x08, 0x04, 0x02, 0x01, 0x02],
  "(": [0x08, 0x04, 0x02, 0x01, 0x00],
  ")": [0x00, 0x01, 0x02, 0x04, 0x08],
  "+": [0x00, 0x14, 0x7F, 0x14, 0x00],
  "=": [0x00, 0x36, 0x36, 0x00, 0x00],
  "@": [0x3E, 0x41, 0x4D, 0x45, 0x3E],
  "#": [0x14, 0x3E, 0x14, 0x3E, 0x14],
  "$": [0x04, 0x7F, 0x50, 0x7F, 0x04],
  "%": [0x32, 0x24, 0x08, 0x26, 0x32],
  "&": [0x36, 0x49, 0x55, 0x22, 0x50],
  "*": [0x00, 0x14, 0x08, 0x14, 0x00],
  "<": [0x08, 0x14, 0x22, 0x41, 0x00],
  ">": [0x00, 0x41, 0x22, 0x14, 0x08],
  "[": [0x7F, 0x41, 0x41, 0x00, 0x00],
  "]": [0x00, 0x41, 0x41, 0x7F, 0x00],
  "{": [0x0E, 0x11, 0x11, 0x11, 0x0E],
  "}": [0x70, 0x08, 0x08, 0x08, 0x70],
  "~": [0x02, 0x01, 0x02, 0x04, 0x02],
  "^": [0x04, 0x02, 0x01, 0x02, 0x04],
  "|": [0x00, 0x41, 0x41, 0x41, 0x00],
  ";": [0x00, 0x56, 0x36, 0x00, 0x00],
};

const CHAR_WIDTH = 5;
const CHAR_HEIGHT = 7;
const CHAR_GAP = 1;
const ROWS = 9; // total display rows (7 + 1 top + 1 bottom padding)
const COLS = 64; // total display columns
const DOT_SIZE = 8;
const DOT_GAP = 2;
const CELL_SIZE = DOT_SIZE + DOT_GAP;

// Preset LED colors
const PRESET_COLORS = [
  { name: "Red", value: "#ff1a1a", glow: "rgba(255,26,26,0.6)" },
  { name: "Green", value: "#00ff41", glow: "rgba(0,255,65,0.6)" },
  { name: "Amber", value: "#ffaa00", glow: "rgba(255,170,0,0.6)" },
  { name: "Cyan", value: "#00e5ff", glow: "rgba(0,229,255,0.6)" },
  { name: "White", value: "#ffffff", glow: "rgba(255,255,255,0.5)" },
  { name: "Magenta", value: "#ff00ff", glow: "rgba(255,0,255,0.6)" },
];

type AnimationMode = "static" | "scroll" | "blink" | "wave";

// Build the dot matrix from text
function buildMatrix(
  text: string,
  width: number,
  rows: number
): boolean[][] {
  const matrix: boolean[][] = Array.from({ length: rows }, () =>
    Array(width).fill(false)
  );
  const upper = text.toUpperCase();
  const yOffset = Math.floor((rows - CHAR_HEIGHT) / 2);
  let colOffset = 0;

  for (let i = 0; i < upper.length; i++) {
    const ch = upper[i];
    const charData = FONT[ch];
    if (!charData) continue;

    for (let c = 0; c < CHAR_WIDTH; c++) {
      if (colOffset + c >= width) break;
      const byte = charData[c];
      for (let r = 0; r < CHAR_HEIGHT; r++) {
        if (byte & (1 << r)) {
          const row = yOffset + r;
          if (row >= 0 && row < rows) {
            matrix[row][colOffset + c] = true;
          }
        }
      }
    }
    colOffset += CHAR_WIDTH + CHAR_GAP;
  }

  return matrix;
}

export default function LEDDisplay() {
  const [text, setText] = useState("HELLO WORLD");
  const [colorIndex, setColorIndex] = useState(0);
  const [brightness, setBrightness] = useState(100);
  const [speed, setSpeed] = useState(50);
  const [animation, setAnimation] = useState<AnimationMode>("scroll");
  const [isPlaying, setIsPlaying] = useState(true);
  const [dotSize, setDotSize] = useState(8);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const scrollOffsetRef = useRef(0);
  const frameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  const blinkStateRef = useRef(true);
  const blinkTimerRef = useRef<number>(0);

  const renderFrame = useCallback(
    (timestamp: number) => {
      const currentColor = PRESET_COLORS[colorIndex];
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const ds = dotSize;
      const dg = Math.max(1, Math.round(ds * 0.3));
      const cell = ds + dg;
      const padding = 12;

      canvas.width = COLS * cell + padding * 2;
      canvas.height = ROWS * cell + padding * 2;

      // Background
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle border
      ctx.strokeStyle = "#1a1a1a";
      ctx.lineWidth = 2;
      ctx.strokeRect(1, 1, canvas.width - 2, canvas.height - 2);

      const alpha = brightness / 100;
      const dt = timestamp - lastTimeRef.current;
      lastTimeRef.current = timestamp;

      // Update scroll offset
      const scrollSpeed = (speed / 50) * 60; // pixels per second
      if (animation === "scroll") {
        scrollOffsetRef.current += (scrollSpeed * dt) / 1000;
      }

      // Update blink
      if (animation === "blink") {
        blinkTimerRef.current += dt;
        if (blinkTimerRef.current > 600) {
          blinkStateRef.current = !blinkStateRef.current;
          blinkTimerRef.current = 0;
        }
      } else {
        blinkStateRef.current = true;
        blinkTimerRef.current = 0;
      }

      // Build the full text matrix (wider than display for scrolling)
  
      const upperText = text.toUpperCase();
      let totalTextWidth = 0;
      for (let i = 0; i < upperText.length; i++) {
        if (FONT[upperText[i]]) {
          totalTextWidth += CHAR_WIDTH + CHAR_GAP;
        }
      }
      totalTextWidth = Math.max(totalTextWidth, COLS);

      const matrix = buildMatrix(text, totalTextWidth, ROWS);

      // Draw LEDs
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          const x = padding + c * cell + ds / 2;
          const y = padding + r * cell + ds / 2;

          // Determine which column of the matrix to read
          let matrixCol = c;
          let isVisible = false;

          if (animation === "scroll") {
            matrixCol = c + Math.floor(scrollOffsetRef.current);
          }

          if (matrixCol >= 0 && matrixCol < totalTextWidth && r < ROWS) {
            isVisible = matrix[r][matrixCol];
          }

          // Wave effect
          let waveAlpha = 1;
          if (animation === "wave") {
            waveAlpha = 0.3 +
              0.7 *
                Math.abs(
                  Math.sin(
                    (timestamp / 1000) * (speed / 25) +
                      c * 0.2 -
                      r * 0.3
                  )
                );
          }

          // Off LED (dim dot)
          const offRadius = ds / 2 * 0.6;
          ctx.beginPath();
          ctx.arc(x, y, offRadius, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(40, 40, 40, 0.5)`;
          ctx.fill();

          // On LED
          if (isVisible && blinkStateRef.current) {
            const finalAlpha = alpha * waveAlpha;
            const radius = ds / 2;

            // Glow
            const gradient = ctx.createRadialGradient(
              x, y, radius * 0.2,
              x, y, radius * 2.5
            );
            gradient.addColorStop(
              0,
              currentColor.glow.replace(
                /[\d.]+\)$/,
                `${finalAlpha * 0.8})`
              )
            );
            gradient.addColorStop(1, "rgba(0,0,0,0)");
            ctx.beginPath();
            ctx.arc(x, y, radius * 2.5, 0, Math.PI * 2);
            ctx.fillStyle = gradient;
            ctx.fill();

            // LED body
            ctx.beginPath();
            ctx.arc(x, y, radius, 0, Math.PI * 2);
            ctx.fillStyle = currentColor.value;
            ctx.globalAlpha = finalAlpha;
            ctx.fill();
            ctx.globalAlpha = 1;

            // Bright center
            ctx.beginPath();
            ctx.arc(x, y, radius * 0.35, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${finalAlpha * 0.6})`;
            ctx.fill();
          }
        }
      }

      // Reset scroll when text has scrolled completely
      if (animation === "scroll") {
        if (scrollOffsetRef.current > totalTextWidth + COLS) {
          scrollOffsetRef.current = -COLS;
        }
      }
    },
    [text, brightness, speed, animation, dotSize, colorIndex]
  );

  useEffect(() => {
    if (!isPlaying) return;
    lastTimeRef.current = performance.now();
    let running = true;
    const loop = (timestamp: number) => {
      if (!running) return;
      renderFrame(timestamp);
      frameRef.current = requestAnimationFrame(loop);
    };
    frameRef.current = requestAnimationFrame(loop);
    return () => {
      running = false;
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [isPlaying, renderFrame]);

  const handleReset = () => {
    scrollOffsetRef.current = 0;
    blinkStateRef.current = true;
    blinkTimerRef.current = 0;
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="border-b border-zinc-800 px-4 py-4 sm:px-6">
        <div className="mx-auto max-w-4xl flex items-center gap-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-red-500/10">
            <Monitor className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">LED Display</h1>
            <p className="text-xs text-zinc-500">
              Dot-matrix LED panel simulator
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 sm:px-6">
        <div className="mx-auto max-w-4xl space-y-6">
          {/* LED Panel */}
          <Card className="border-zinc-800 bg-zinc-900 overflow-hidden">
            <CardContent className="p-0">
              {/* Realistic bezel */}
              <div className="bg-gradient-to-b from-zinc-700 to-zinc-800 p-3 sm:p-4 rounded-t-lg">
                <div className="bg-zinc-950 rounded-md p-1 shadow-[inset_0_2px_8px_rgba(0,0,0,0.8)]">
                  <div className="flex justify-center">
                    <canvas
                      ref={canvasRef}
                      className="block max-w-full h-auto rounded"
                      style={{ imageRendering: "pixelated" }}
                    />
                  </div>
                </div>
              </div>
              {/* Status bar */}
              <div className="flex items-center justify-between px-4 py-2 bg-zinc-800/50 text-[10px] text-zinc-500 font-mono">
                <span>
                  {COLS}×{ROWS} DOT MATRIX
                </span>
                <span className="flex items-center gap-1.5">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isPlaying ? "bg-green-500" : "bg-zinc-600"
                    }`}
                  />
                  {isPlaying ? "RUNNING" : "PAUSED"}
                </span>
                <span>{PRESET_COLORS[colorIndex].name.toUpperCase()}</span>
              </div>
            </CardContent>
          </Card>

          {/* Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Text Input */}
            <Card className="border-zinc-800 bg-zinc-900 sm:col-span-2">
              <CardHeader className="pb-3 pt-4 px-4">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Type className="w-4 h-4 text-zinc-400" />
                  Display Text
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <div className="flex gap-2">
                  <Input
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Enter text..."
                    maxLength={50}
                    className="bg-zinc-800 border-zinc-700 text-zinc-100 placeholder:text-zinc-600 font-mono"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleReset}
                    className="shrink-0 border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="shrink-0 border-zinc-700 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800"
                  >
                    {isPlaying ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Color Selection */}
            <Card className="border-zinc-800 bg-zinc-900">
              <CardHeader className="pb-3 pt-4 px-4">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-zinc-400" />
                  LED Color
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map((color, i) => (
                    <button
                      key={color.name}
                      onClick={() => setColorIndex(i)}
                      className={`w-9 h-9 rounded-full border-2 transition-all hover:scale-110 ${
                        colorIndex === i
                          ? "border-white scale-110 shadow-lg"
                          : "border-zinc-600"
                      }`}
                      style={{
                        backgroundColor: color.value,
                        boxShadow:
                          colorIndex === i
                            ? `0 0 12px ${color.glow}`
                            : undefined,
                      }}
                      title={color.name}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Animation Mode */}
            <Card className="border-zinc-800 bg-zinc-900">
              <CardHeader className="pb-3 pt-4 px-4">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-zinc-400" />
                  Animation
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <ToggleGroup
                  type="single"
                  value={animation}
                  onValueChange={(v) => {
                    if (v) {
                      setAnimation(v as AnimationMode);
                      handleReset();
                    }
                  }}
                  className="flex-wrap gap-1"
                >
                  <ToggleGroupItem
                    value="static"
                    className="text-xs data-[state=on]:bg-red-500/20 data-[state=on]:text-red-400 border-zinc-700"
                  >
                    Static
                  </ToggleGroupItem>
                  <ToggleGroupItem
                    value="scroll"
                    className="text-xs data-[state=on]:bg-red-500/20 data-[state=on]:text-red-400 border-zinc-700"
                  >
                    Scroll
                  </ToggleGroupItem>
                  <ToggleGroupItem
                    value="blink"
                    className="text-xs data-[state=on]:bg-red-500/20 data-[state=on]:text-red-400 border-zinc-700"
                  >
                    Blink
                  </ToggleGroupItem>
                  <ToggleGroupItem
                    value="wave"
                    className="text-xs data-[state=on]:bg-red-500/20 data-[state=on]:text-red-400 border-zinc-700"
                  >
                    Wave
                  </ToggleGroupItem>
                </ToggleGroup>
              </CardContent>
            </Card>

            {/* Brightness */}
            <Card className="border-zinc-800 bg-zinc-900">
              <CardHeader className="pb-3 pt-4 px-4">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-zinc-400" />
                    Brightness
                  </span>
                  <span className="text-xs text-zinc-500 font-mono">
                    {brightness}%
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <Slider
                  value={[brightness]}
                  onValueChange={([v]) => setBrightness(v)}
                  min={10}
                  max={100}
                  step={5}
                  className="py-2"
                />
              </CardContent>
            </Card>

            {/* Speed */}
            <Card className="border-zinc-800 bg-zinc-900">
              <CardHeader className="pb-3 pt-4 px-4">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Gauge className="w-4 h-4 text-zinc-400" />
                    Speed
                  </span>
                  <span className="text-xs text-zinc-500 font-mono">
                    {speed}%
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <Slider
                  value={[speed]}
                  onValueChange={([v]) => setSpeed(v)}
                  min={10}
                  max={100}
                  step={5}
                  className="py-2"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 px-4 py-3 mt-auto">
        <div className="mx-auto max-w-4xl text-center text-xs text-zinc-600">
          LED Display Simulator • Built with Next.js & Canvas API
        </div>
      </footer>
    </div>
  );
}